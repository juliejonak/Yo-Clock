
Excess DOM made elements

//Create time input div
// const timeBox = document.createElement('div');
// timeBox.style = 'display: flex; align-items: center; margin-bottom: 10px;';
// textBox.appendChild(timeBox);
// timeBox.classList.add('time');

// //Create Label in timeBox
// const timeLabel = document.createElement('label');
// timeLabel.setAttribute('for', 'number');
// timeLabel.innerHTML = 'How much time?';
// timeLabel.style = 'font-size: 14px; margin-right: 5%;';
// timeBox.appendChild(timeLabel);

// //Create input in timeBox
// const timeInput = document.createElement('input');
// timeInput.setAttribute('id', 'number');
// timeInput.setAttribute('type', 'number');
// timeInput.setAttribute('value', '25');
// timeInput.style = 'width: 25%; font-size: 12px;';
// timeBox.appendChild(timeInput);

// //Create task input div
// const taskBox = document.createElement('div');
// taskBox.style = 'display: flex; flex-direction: column; flex-wrap: wrap;';
// textBox.appendChild(taskBox);
// taskBox.classList.add('task');

// //Create task label in taskBox
// const taskLabel = document.createElement('label');
// taskLabel.setAttribute('for', 'input');
// taskLabel.innerHTML = 'What task do you need to accomplish afterwards?';
// taskLabel.style = 'font-size: 14px; line-height: 17px; margin-bottom: 15px;';
// taskBox.appendChild(taskLabel);


// //Create task text area in taskBox
// const taskText = document.createElement('textarea');
// taskText.setAttribute('id', 'input');
// taskText.setAttribute('name', 'userInput');
// taskText.setAttribute('rows', '4');
// taskText.setAttribute('cols', '5');
// taskText.setAttribute('maxlength', '200');
// taskText.setAttribute('wrap', 'hard');
// taskText.setAttribute('placeholder', 'Walk Mr. Chewbarka');
// taskText.style = 'width: 80%; font-size: 13px; padding-top: 5px; padding-left: 3%;';
// taskBox.appendChild(taskText);
